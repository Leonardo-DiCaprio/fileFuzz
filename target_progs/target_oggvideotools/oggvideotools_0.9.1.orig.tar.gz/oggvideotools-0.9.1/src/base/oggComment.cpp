#include "oggComment.h"

OggComment::OggComment()
{
}

OggComment::~OggComment()
{
}
