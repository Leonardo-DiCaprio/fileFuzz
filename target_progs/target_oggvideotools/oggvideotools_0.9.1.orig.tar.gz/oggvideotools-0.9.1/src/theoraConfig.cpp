#include "theoraConfig.h"

TheoraConfig::TheoraConfig()
{
}

TheoraConfig::~TheoraConfig()
{
}
