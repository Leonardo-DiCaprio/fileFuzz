#ifndef helper_h
#define helper_h

#include <string>

//! returns true, if file exists and should not be overwritten
bool check_file_exists (std::string& filename);

#endif
