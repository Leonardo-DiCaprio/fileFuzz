//
// C++ Implementation: effector
//
// Description:
//
//
// Author: Yorn <yorn@gmx.net>, (C) 2009
//
// Copyright: See COPYING file that comes with this distribution
//
//
#include "effector.h"

Effector::Effector()
{
}


Effector::~Effector()
{
}


