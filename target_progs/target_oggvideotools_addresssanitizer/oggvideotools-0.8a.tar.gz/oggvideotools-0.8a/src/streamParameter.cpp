#include "streamParameter.h"

StreamParameter::StreamParameter()
{
}

StreamParameter::~StreamParameter()
{
}
